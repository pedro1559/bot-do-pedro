const config = {
        botName: 'BOT DO PEDRO 🤙🐊 ',
        ownerName: 'PEDRO 🤙🐊',
}
