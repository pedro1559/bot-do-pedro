const menuadmin = (prefix, pushname) => {
 return `oiin aqui e o menu dos admins
 _obs para o bot executar esses comandos e nescessario dar adm para o bot_
 
 ◪ *COMANDO DOS ADMINS*
 │
 ├─ ❏ ${prefix}opengc
 ├─ ❏ ${prefix}closegc
 ├─ ❏ ${prefix}promote
 ├─ ❏ ${prefix}demote
 ├─ ❏ ${prefix}tagall
 ├─ ❏ ${prefix}tagall2
 ├─ ❏ ${prefix}tagall3
 ├─ ❏ ${prefix}tagall4
 ├─ ❏ ${prefix}tagall5
 ├─ ❏ ${prefix}add
 ├─ ❏ ${prefix}kick
 ├─ ❏ ${prefix}listadmins
 ├─ ❏ ${prefix}linkgroup
 ├─ ❏ ${prefix}leave
 ├─ ❏ ${prefix}welcome
 ├─ ❏ ${prefix}nsfw
 ├─ ❏ ${prefix}leveling
 ├─ ❏ ${prefix}level
 ├─ ❏ ${prefix}delete
 ├─ ❏ ${prefix}simih
 └─ ❏ ${prefix}ownergroup
 `


}

exports.menuadmin = menuadmin