const nabutomenu = (prefix, pushname) => {
    return `◪ *Comandos do ninem*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.nabutomenu = nabutomenu
