const help = (prefix) => {
	return `         *PEDRO 🤙🐊*

 INFO:✅

 *DONO* : PEDRO 🤙🐊

 *WHATSAPPS DO PROPRIETÁRIOS/* :
 
 *CRÉDITOS* (PEDRO 🤙🐊): wa.me/5512996299061


   [𝑨𝑳𝑮𝑼𝑵𝑺 𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺 𝑵𝑨̃𝑶 𝑬𝑺𝑻𝑨̃𝑶 𝑭𝑼𝑵𝑪𝑰𝑶𝑵𝑨𝑵𝑫𝑶, 𝑺𝑬 𝑨𝑪𝑯𝑨𝑹 𝑹𝑼𝑰𝑴 𝑬́ 𝑺𝑰𝑴𝑷𝑳𝑬𝑺 𝑷𝑨𝑹𝑨 𝑫𝑬 𝑼𝑺𝑨𝑹, 𝑮𝑹𝑨𝑻𝑶!]



 
    𝑩𝑬𝑴 𝑽𝑰𝑵𝑫𝑶 𝑨𝑶 𝑴𝑬𝑵𝑼 𝑫𝑶 𝑩𝑶𝑻🤭



 
         【 $INÚTEIS* 】 :

  ➡ ${prefix}blocklist
     【LISTA DE BLOCK】
  ➡ ${prefix}chatlist
     【LISTA CHAT】❌
  ➡ ${prefix}ping
     【PING】
  ➡ ${prefix}bugreport
     【REPORTA BUG】❌


      
      *ZOAÇÃO* :


  ➡ ${prefix}%GADO
   
  ➡ ${prefix}%CORNO(A)

  ➡ ${prefix}%NAMORARESSEANO

  ➡ ${prefix}%GAY




    【 *MAIS USADOS RECENTEMENTE* 】
  
  ➡ ${prefix}sticker
    【FAZER FIGURINHA】
  ➡ ${prefix}toimg
    【CONVERTE FIGURINHA EM IMAGEM】
  ➡ ${prefix}tomp3
    【PEGAR ÁUDIO DE ALGUM VÍDEO】

 

     【FOTOS ANIME/LOLI e etc】
 

  ➡${prefix}loli
  【foto de loli】

  ➡${prefix}nekoanime
   【NEKO ANIME】

  ➡${prefix}randomanime
   【anime aleatório】


  ➡${prefix}pokémon
   【foto de pokémon】


   


     


        *MELHORES SOBRE ÁUDIO*
 
  ➡ ${prefix}play nome da música
    【DOWNLOAD MÚSICA】
  ➡ ${prefix}tts pt texto
    【FALAR SEU TEXTO】



      +18 *NÃO USE NO GRUPO SUJEITO A BAN*

  
  ➡${prefix}hentai
    【foto hentai】

  ➡${prefix}randomhentaio
    【random hentai】






      

         【 𝑶𝑼𝑻𝑹𝑶𝑺 】
  
  ➡ ${prefix}send
  ➡ ${prefix}wame
  ➡ ${prefix}exe
  ➡ ${prefix}qrcode
  ➡ ${prefix}afk
  ➡ ${prefix}timer
  ➡ ${prefix}fml
  ➡ ${prefix}fml2







          【 *FONTES* 】

  ➡ ${prefix}bpink
  ➡ ${prefix}marvellogo
  ➡ ${prefix}snowwrite
  ➡ ${prefix}3dtext
  ➡ ${prefix}ninjalogo
  ➡ ${prefix}water
  ➡ ${prefix}firetext
  ➡ ${prefix}logowolf
  ➡ ${prefix}logowolf2
  ➡ ${prefix}phlogo
  ➡ ${prefix}glitch        𝑨 𝑴𝑨𝑰𝑶𝑹𝑰𝑨 𝑵𝑨̃𝑶 𝑷𝑬𝑮𝑨         
  ➡ ${prefix}neonlogo
  ➡ ${prefix}neonlogo2
  ➡ ${prefix}lionlogo
  ➡ ${prefix}jokerlogo
  ➡ ${prefix}shadow
  ➡ ${prefix}burnpaper
  ➡ ${prefix}coffee
  ➡ ${prefix}lovepaper
  ➡ ${prefix}woodblock
  ➡ ${prefix}qowheart
  ➡ ${prefix}mutgrass
  ➡ ${prefix}undergocean
  ➡ ${prefix}woodenboards
  ➡ ${prefix}wolfmetal
  ➡ ${prefix}metalictglow
  ➡ ${prefix}8bit
  ➡ ${prefix}ttp
  ➡ ${prefix}herrypotter
  ➡ ${prefix}pubglogo
  ➡ ${prefix}quotemaker
        
       【 *MEDIA* 】
  

  ➡ ${prefix}trendtwit
  ➡ ${prefix}randomkpop
     【FOTOS ALEATÓRIA DE KPOP🤢】
  ➡ ${prefix}ytsearch
    【PESQUISA】
      


      【  *EDUCAÇÃO* 】
  
  ➡ ${prefix}wiki
  ➡ ${prefix}wikien
  ➡ ${prefix}nulis
  ➡ ${prefix}quotes
  ➡ ${prefix}quotes2
  ➡ ${prefix}artinama


     【 *DOWNLOADER* 】
  
  ➡ ${prefix}images
    【IMAGENS ALEATÓRIA】
  ➡ ${prefix}ytmp3
    【MP3】
  ➡ ${prefix}ytmp4
    【DOWNLOAD MP4(VIDEO)】
  ➡ ${prefix}tiktok
  ➡ ${prefix}joox
         

           *MEME*
      


  ➡  ${prefix}meme
  ➡ 【MEME INDONÉSIO】
  ➡  ${prefix}memeindo
  ➡ 【MEMEINDO INDONESIO】
 




     【 *MÚSICA* 】
  
  ➡ ${prefix}lirik
  ➡ ${prefix}chord



       ➡ *ISLAM*
  
   ➡ ${prefix}quran





       【 *STALK* 】
  
  
  ➡ ${prefix}tiktokstalk
     【stalkear tik tok】
  ➡ ${prefix}igstalk





        【 *WIBU* 】

  
  ➡ ${prefix}neonime
  ➡ ${prefix}pokemon
  ➡ ${prefix}loli
  ➡ ${prefix}waifu
  ➡ ${prefix}randomanime
  ➡ ${prefix}husbu
  ➡ ${prefix}husbu2
  ➡ ${prefix}wait
  ➡ ${prefix}nekonime



      【 *DIVERSÃO* 】
  
  ➡ ${prefix}alay
  ➡ ${prefix}gantengcek
  ➡ ${prefix}watak
  ➡ ${prefix}hobby
  ➡ ${prefix}game
  ➡ ${prefix}bucin
  ➡ ${prefix}trust
  ➡ ${prefix}dare
  ➡ ${prefix}simi





         【 *INFORMAÇÃO* 】
  
  ➡ ${prefix}bahasa
     【SABER TODOS CÓDIGO DE PAIS】
  ➡ ${prefix}kodenegara
  ➡ ${prefix}kbbi
  ➡ ${prefix}fakta
  ➡ ${prefix}infocuaca
  ➡ ${prefix}infogempa
  ➡ ${prefix}jadwaltvnow
  ➡ ${prefix}covid


          【 SÓ FUNCIONA COM O DONO 】


  
   ➭ ${prefix}setprefix
     【MUDAR PREFIXO】
   ➭ ${prefix}block
     【BLOQUEAR】
   ➭ ${prefix}bc
     【TM】
   ➭ ${prefix}bcgc
     【TM SÓ PARA MEMBROS DO GP】
   ➭ ${prefix}clearall
     【APAGAR TODAS MSG】

`
}

exports.help = help
